var searchData=
[
  ['row_0',['row',['../struct_ticker_state.html#aac2945af8db1582f4dc78e31f8d6154c',1,'TickerState']]]
];
